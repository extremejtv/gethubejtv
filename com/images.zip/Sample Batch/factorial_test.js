// test function for factorial code
alert ("The factorial of five is "+factorial(5));