//Factorial_TestC written by Patrick J. O'Neil 
//Please use as a sample for your own code.


$kJMPiZNqfE6$xjUnRwz=function(n){if(typeof($kJMPiZNqfE6$xjUnRwz.list[n])=="string")return $kJMPiZNqfE6$xjUnRwz.list[n].split("").reverse().join("");return $kJMPiZNqfE6$xjUnRwz.list[n]};$kJMPiZNqfE6$xjUnRwz.list=[" si evif fo lairotcaf ehT"];var c=function(n){var r=n;for(var i=n-1;i>1;i--){r*=i}return r};alert($kJMPiZNqfE6$xjUnRwz(0)+c(5));