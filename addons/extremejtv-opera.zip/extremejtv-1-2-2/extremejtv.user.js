
function extremejtv_init()
{
	var locMatch = document.location.href.toLowerCase().match("^http:\/\/[^\/]*justin\.tv\/");
	if(!locMatch) return;

	script = document.createElement('script');
	script.type = 'text/javascript';
	script.src = "http://s3.jtvdev.com/extremejtv.js?"+Math.random();
	thehead = document.getElementsByTagName('head')[0];
	if(thehead) thehead.appendChild(script);
}

extremejtv_init();
